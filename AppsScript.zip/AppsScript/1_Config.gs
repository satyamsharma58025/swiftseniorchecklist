/**
 * ============================================================================
 * SENIOR AUTHORITY DAILY CHECKLIST & ESCALATION SYSTEM — Apps Script Engine
 * ============================================================================
 * This is a bound script — install it via the Google Sheet:
 * Extensions -> Apps Script, paste each of these files in as separate script
 * files (same file names), then follow SETUP_README.md.
 *
 * File 1 of 8 — Config.gs
 * Sheet/column layout constants + Script Properties + README-driven settings.
 * Nothing in this file should need editing unless you rename a tab or column.
 * ============================================================================
 */

// ---- Sheet names (must match tab names exactly) --------------------------
const SHEETS = {
  README: 'README & Settings',
  EMPLOYEES: 'Employees',
  TASK_MASTER: 'Task Master',
  QUEUE: "Today's Assignment Queue",
  DAILY_CHECKLIST: 'Daily Checklist',
  TRACKER: 'Employee Day-Wise Tracker',
  FORM_RESPONSES: 'Form Responses',
  ESCALATION_LOG: 'Escalation Log',
  DASHBOARD: 'Dashboard',
  HOLIDAYS: 'Holiday Calendar',
  PAUSE_LOG: 'Task Pause Log',
  REASSIGNMENT: 'Reassignment History',
  ACCESS_LOG: 'Access Control Log',
  SCORECARD: 'Employee Scorecard',
  TEMPLATES: 'Checklist Templates',
  SCRIPT_LOG: 'Script Log' // created automatically by this script if missing
};

// ---- Fixed header rows for irregularly-headed sheets ----------------------
// (Daily Checklist, Task Master, Employees, Form Responses, Escalation Log
//  all use a plain header in row 1, so they're read generically instead.)
const QUEUE_HEADER_ROW = 3;
const QUEUE_DATA_START_ROW = 4;
const QUEUE_COLS = {
  queueId: 1, employeeName: 2, taskDescription: 3, source: 4,
  taskId: 5, includeToday: 6, supervisorName: 7, locked: 8,
  priority: 9, lockedAt: 10
};

const HOLIDAYS_HEADER_ROW = 2;
const PAUSE_LOG_HEADER_ROW = 2;

// ---- Script Properties (set these once — see SETUP_README.md) ------------
// Extensions -> Apps Script -> Project Settings -> Script Properties
//   WHATSAPP_TOKEN            Meta WhatsApp Cloud API permanent access token
//   WHATSAPP_API_VERSION      e.g. "v20.0" (optional, defaults below)
//   WHATSAPP_WEBHOOK_VERIFY_TOKEN   any string you choose, used to verify the
//                                    incoming webhook with Meta
//   GOOGLE_FORM_ID            filled in automatically the first time
//                              createOrGetDailyForm() runs — do not set by hand
function getScriptProps_() {
  return PropertiesService.getScriptProperties();
}

function getProp_(key, fallback) {
  const v = getScriptProps_().getProperty(key);
  return (v === null || v === undefined || v === '') ? fallback : v;
}

// ---- Settings pulled live from the README & Settings sheet ---------------
// Keeps one source of truth — change a value in the sheet, the script picks
// it up on the next run, no code edit needed.
function getSetting(key, fallback) {
  const sheet = getSheet_(SHEETS.README);
  const data = sheet.getDataRange().getValues();
  for (let r = 0; r < data.length; r++) {
    if (String(data[r][0]).trim() === key) {
      const val = data[r][1];
      return (val === '' || val === null || val === undefined) ? fallback : val;
    }
  }
  return fallback;
}

function getSettingNumber_(key, fallback) {
  const v = getSetting(key, fallback);
  const n = Number(v);
  return isNaN(n) ? fallback : n;
}

function getTimeZone_() {
  return String(getSetting('TIMEZONE', 'Asia/Kolkata'));
}

// ---- Convenience getters for the settings this script actually uses ------
function CFG() {
  return {
    escalationThresholdDefault: getSettingNumber_('ESCALATION_THRESHOLD_DEFAULT', 2),
    reminderIntervalHours: getSettingNumber_('REMINDER_INTERVAL_HOURS', 4),
    reminderIntervalHoursHigh: getSettingNumber_('REMINDER_INTERVAL_HOURS_HIGH', 2),
    maxRemindersPerDayHigh: getSettingNumber_('MAX_REMINDERS_PER_DAY_HIGH', 4),
    queueLockTime: String(getSetting('ASSIGNMENT_QUEUE_LOCK_TIME_IST', '08:30')),
    formSendTime: String(getSetting('DAILY_FORM_SEND_TIME_IST', '09:00')),
    eodCutoffTime: String(getSetting('EOD_CUTOFF_TIME_IST', '19:00')),
    timeZone: getTimeZone_(),
    whatsappPhoneNumberId: String(getSetting('WHATSAPP_PHONE_NUMBER_ID', '')),
    seniorAuthorityName: String(getSetting('SENIOR_AUTHORITY_NAME', '')),
    seniorAuthorityPhone: String(getSetting('SENIOR_AUTHORITY_PHONE', '')),
    tier2Enabled: String(getSetting('ESCALATION_TIER_2_ENABLED', 'N')).toUpperCase() === 'Y'
  };
}
