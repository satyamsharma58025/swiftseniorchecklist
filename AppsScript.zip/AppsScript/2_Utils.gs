/**
 * File 2 of 8 — Utils.gs
 * Generic sheet helpers, logging, date/time utilities. Header-name-based
 * (not fixed column-index-based) so the script survives someone inserting
 * or reordering a column in a plain single-header-row sheet.
 */

function getSheet_(name) {
  const sh = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sh) throw new Error('Sheet not found: ' + name);
  return sh;
}

/** Map of header text -> 1-based column index, for a sheet whose header is in `headerRow`. */
function headerMap_(sheet, headerRow) {
  const lastCol = sheet.getLastColumn();
  const headers = sheet.getRange(headerRow, 1, 1, lastCol).getValues()[0];
  const map = {};
  headers.forEach((h, i) => {
    if (h !== '' && h !== null) map[String(h).trim()] = i + 1;
  });
  return map;
}

/**
 * Reads every data row of `sheet` (header assumed in `headerRow`, data starts
 * the row after) into an array of plain objects keyed by header text, each
 * carrying a `_row` property with its 1-based sheet row number.
 */
function readRows_(sheet, headerRow) {
  const map = headerMap_(sheet, headerRow);
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow <= headerRow) return { map: map, rows: [] };
  const values = sheet.getRange(headerRow + 1, 1, lastRow - headerRow, lastCol).getValues();
  const rows = values.map((rowArr, i) => {
    const obj = { _row: headerRow + 1 + i };
    Object.keys(map).forEach(h => { obj[h] = rowArr[map[h] - 1]; });
    return obj;
  });
  return { map: map, rows: rows };
}

/** Writes a single header-named field on a specific sheet row. */
function setField_(sheet, map, row, header, value) {
  const col = map[header];
  if (!col) throw new Error('Unknown column "' + header + '" on ' + sheet.getName());
  sheet.getRange(row, col).setValue(value);
}

function getField_(sheet, map, row, header) {
  const col = map[header];
  if (!col) throw new Error('Unknown column "' + header + '" on ' + sheet.getName());
  return sheet.getRange(row, col).getValue();
}

// ---- Date helpers (all in the workbook's configured time zone) -----------
function todayStr_() {
  return Utilities.formatDate(new Date(), CFG().timeZone, 'yyyy-MM-dd');
}
function dateOnly_(d) {
  return Utilities.formatDate(new Date(d), CFG().timeZone, 'yyyy-MM-dd');
}
function nowTimestamp_() {
  return new Date();
}
function weekdayName_(d) {
  return Utilities.formatDate(new Date(d), CFG().timeZone, 'EEEE'); // "Monday"
}
function dayOfMonth_(d) {
  return Number(Utilities.formatDate(new Date(d), CFG().timeZone, 'd'));
}
function monthNum_(d) {
  return Number(Utilities.formatDate(new Date(d), CFG().timeZone, 'M'));
}
function hoursBetween_(a, b) {
  return Math.abs(new Date(b).getTime() - new Date(a).getTime()) / 36e5;
}

// ---- Logging ---------------------------------------------------------------
/** Appends a row to a 'Script Log' sheet, creating it on first use. Never throws. */
function logEvent_(fn, level, message) {
  try {
    let sh = SpreadsheetApp.getActive().getSheetByName(SHEETS.SCRIPT_LOG);
    if (!sh) {
      sh = SpreadsheetApp.getActive().insertSheet(SHEETS.SCRIPT_LOG);
      sh.appendRow(['Timestamp', 'Function', 'Level', 'Message']);
      sh.getRange(1, 1, 1, 4).setFontWeight('bold');
      sh.setFrozenRows(1);
    }
    sh.appendRow([new Date(), fn, level, message]);
  } catch (e) {
    // Logging must never break the calling function.
  }
}
function logInfo_(fn, msg) { logEvent_(fn, 'INFO', msg); }
function logWarn_(fn, msg) { logEvent_(fn, 'WARN', msg); }
function logError_(fn, err) { logEvent_(fn, 'ERROR', (err && err.stack) ? err.stack : String(err)); }

/** Wraps a function so a failure is logged (and, for menu items, surfaced to the user) instead of silently dying. */
function runSafely_(fnName, fn, notifyUi) {
  try {
    fn();
  } catch (e) {
    logError_(fnName, e);
    if (notifyUi) {
      try { SpreadsheetApp.getUi().alert(fnName + ' failed: ' + e.message); } catch (uiErr) {}
    }
  }
}

// ---- Small string helpers --------------------------------------------------
function nextSequence_(sheet, headerRow, idHeader, prefix, padLen) {
  const { rows } = readRows_(sheet, headerRow);
  let max = 0;
  rows.forEach(r => {
    const id = String(r[idHeader] || '');
    const m = id.match(new RegExp('^' + prefix + '(\\d+)$'));
    if (m) max = Math.max(max, Number(m[1]));
  });
  return prefix + String(max + 1).padStart(padLen, '0');
}
