/**
 * File 3 of 8 — WhatsApp.gs
 * Sending via Meta's WhatsApp Business Cloud API, and receiving employee
 * replies via an inbound webhook (requires deploying this project as a
 * Web App — see SETUP_README.md, section 4).
 */

function sendWhatsAppText_(toPhone, message) {
  const token = getProp_('WHATSAPP_TOKEN', '');
  const phoneNumberId = CFG().whatsappPhoneNumberId;
  const apiVersion = getProp_('WHATSAPP_API_VERSION', 'v20.0');

  if (!token || !phoneNumberId) {
    logWarn_('sendWhatsAppText_', 'Skipped — WHATSAPP_TOKEN or WHATSAPP_PHONE_NUMBER_ID not configured.');
    return { ok: false, reason: 'not_configured' };
  }
  if (!toPhone || String(toPhone).indexOf('TBD') !== -1) {
    logWarn_('sendWhatsAppText_', 'Skipped — recipient phone is TBD/blank: ' + toPhone);
    return { ok: false, reason: 'no_phone' };
  }

  const url = 'https://graph.facebook.com/' + apiVersion + '/' + phoneNumberId + '/messages';
  const payload = {
    messaging_product: 'whatsapp',
    to: String(toPhone).replace(/[^0-9]/g, ''),
    type: 'text',
    text: { preview_url: true, body: message }
  };
  const options = {
    method: 'post',
    contentType: 'application/json',
    headers: { Authorization: 'Bearer ' + token },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    const resp = UrlFetchApp.fetch(url, options);
    const code = resp.getResponseCode();
    if (code >= 200 && code < 300) {
      return { ok: true, response: resp.getContentText() };
    }
    logWarn_('sendWhatsAppText_', 'WhatsApp API returned ' + code + ': ' + resp.getContentText());
    return { ok: false, reason: 'http_' + code, body: resp.getContentText() };
  } catch (e) {
    logError_('sendWhatsAppText_', e);
    return { ok: false, reason: 'exception', error: String(e) };
  }
}

/**
 * Deploy this project as a Web App (Deploy -> New deployment -> Web app,
 * execute as yourself, access "Anyone") and register the resulting /exec
 * URL as the webhook URL in Meta's WhatsApp Business Platform app config.
 * Meta calls doGet once, to verify the webhook (hub.challenge handshake);
 * after that every inbound message arrives as a POST to doPost.
 */
function doGet(e) {
  const verifyToken = getProp_('WHATSAPP_WEBHOOK_VERIFY_TOKEN', '');
  if (e && e.parameter && e.parameter['hub.mode'] === 'subscribe' &&
      e.parameter['hub.verify_token'] === verifyToken) {
    return ContentService.createTextOutput(e.parameter['hub.challenge']);
  }
  return ContentService.createTextOutput('OK');
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const entry = (body.entry && body.entry[0]) || {};
    const change = (entry.changes && entry.changes[0]) || {};
    const value = change.value || {};
    const messages = value.messages;
    if (!messages || !messages.length) {
      return ContentService.createTextOutput('OK'); // status callbacks, etc. — ignore
    }
    messages.forEach(m => {
      const fromPhone = m.from; // digits only, e.g. "918250685227"
      const text = (m.text && m.text.body) || '';
      recordEmployeeReply_(fromPhone, text);
    });
  } catch (err) {
    logError_('doPost', err);
  }
  return ContentService.createTextOutput('OK');
}

/**
 * Finds that employee's most recent open (Pending / Not Done, not yet
 * Done) task for today on the Daily Checklist and records their reply
 * against it. If they have more than one open task, the reply is recorded
 * against the oldest-unanswered one and flagged for manual reconciliation
 * so nothing is silently misattributed.
 */
function recordEmployeeReply_(fromPhone, text) {
  const sheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const { map, rows } = readRows_(sheet, 1);
  const today = todayStr_();
  const digits = String(fromPhone).replace(/[^0-9]/g, '');

  // Match phone -> Employee Name via Employees sheet
  const empSheet = getSheet_(SHEETS.EMPLOYEES);
  const { rows: empRows } = readRows_(empSheet, 1);
  const emp = empRows.find(r => String(r['Phone']).replace(/[^0-9]/g, '') === digits);
  if (!emp) {
    logWarn_('recordEmployeeReply_', 'Reply from unknown number ' + fromPhone + ': "' + text + '"');
    return;
  }

  const candidates = rows.filter(r =>
    dateOnly_(r['Date']) === today &&
    r['Employee Name'] === emp['Employee Name'] &&
    r['Status'] !== 'Done' &&
    !r['Employee Response']
  );

  if (candidates.length === 0) {
    logWarn_('recordEmployeeReply_', 'No open task found today for ' + emp['Employee Name'] + '. Reply: "' + text + '"');
    return;
  }
  const target = candidates[0];
  setField_(sheet, map, target._row, 'Employee Response (via WhatsApp)', text);
  setField_(sheet, map, target._row, 'Employee Response At', nowTimestamp_());
  if (candidates.length > 1) {
    setField_(sheet, map, target._row, 'Needs Manual Reconciliation (Y/N)', 'Y');
  }
  logInfo_('recordEmployeeReply_', 'Recorded reply from ' + emp['Employee Name'] + ' on ' + target['Checklist ID']);
}
