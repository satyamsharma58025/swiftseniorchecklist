/**
 * File 4 of 8 — ChecklistGeneration.gs
 * Expands Task Master's recurring definitions into today's draft rows in
 * "Today's Assignment Queue", for the manager to review before locking.
 * Run automatically ~06:00 IST (see Triggers.gs) or on demand from the menu.
 */

function generateTodaysQueue() {
  const today = new Date();
  const todayStr = todayStr_();
  const taskSheet = getSheet_(SHEETS.TASK_MASTER);
  const { map: tMap, rows: tasks } = readRows_(taskSheet, 1);

  const holidays = getHolidayDatesForDailyCadence_();
  const isSunday = (weekdayName_(today) === 'Sunday');

  const queueSheet = getSheet_(SHEETS.QUEUE);
  const existing = readQueueRows_(queueSheet);
  // Avoid double-drafting: skip a Task ID that's already in today's (unlocked) queue.
  const alreadyQueuedTaskIds = new Set(
    existing.filter(r => !r.locked).map(r => r.taskId).filter(Boolean)
  );

  let added = 0;
  tasks.forEach(t => {
    if (String(t['Active (Y/N)']).toUpperCase() !== 'Y') return;
    if (String(t['Paused (Y/N — formula, do not hand-edit)']).toUpperCase() === 'Y') return;
    if (!inDateRange_(t['Start Date'], t['End Date'], today)) return;
    if (alreadyQueuedTaskIds.has(t['Task ID'])) return;

    if (!cadenceMatchesToday_(t, today, todayStr, holidays, isSunday)) return;

    appendQueueRow_(queueSheet, {
      employeeName: t['Employee Name'],
      taskDescription: t['Task Description'],
      source: 'Auto',
      taskId: t['Task ID'],
      includeToday: 'Y',
      supervisorName: t['Supervisor Name']
    });
    added++;
  });

  logInfo_('generateTodaysQueue', 'Drafted ' + added + ' task instance(s) for ' + todayStr + '.');
  return added;
}

/** True if `task`'s cadence fires on `today`. Cadence-specific rules live here — see comments. */
function cadenceMatchesToday_(t, today, todayStr, holidays, isSunday) {
  const cadence = String(t['Cadence (Daily/Weekly/Monthly)']).trim();
  const detail = String(t['Schedule Detail (Weekday / Day-of-Month)']).trim();

  if (cadence === 'Daily') {
    if (isSunday) return false;                 // hardcoded weekly-off, per README
    if (holidays.has(todayStr)) return false;    // Holiday Calendar (Daily-cadence only, per README)
    return true;
  }

  if (cadence === 'Weekly') {
    return weekdayName_(today) === detail; // detail e.g. "Monday"
  }

  if (cadence === 'Monthly') {
    const dom = Number(detail);
    if (isNaN(dom)) {
      logWarn_('cadenceMatchesToday_', 'Task ' + t['Task ID'] + ': Monthly cadence needs a numeric day-of-month, got "' + detail + '" — skipped.');
      return false;
    }
    return dayOfMonth_(today) === dom;
  }

  if (cadence === 'Quarterly') {
    // Assumes Indian-FY quarter-end months (Jun/Sep/Dec/Mar). Adjust here if
    // your quarters run differently.
    const dom = Number(detail);
    if (isNaN(dom)) {
      logWarn_('cadenceMatchesToday_', 'Task ' + t['Task ID'] + ': Quarterly cadence needs a numeric day-of-month — skipped.');
      return false;
    }
    const qMonths = [3, 6, 9, 12];
    return dayOfMonth_(today) === dom && qMonths.indexOf(monthNum_(today)) !== -1;
  }

  if (cadence === 'Yearly') {
    // Expected format: "DD-Mon" (e.g. "31-Jul") or "DD-Mon / DD-Mon" for two
    // due dates (e.g. Income Tax Return Filing). A bare number with no month
    // (flagged in the README, e.g. T-Y-002) cannot be scheduled — it is
    // skipped and logged so it surfaces in Script Log instead of silently
    // never firing.
    const parts = detail.split('/').map(s => s.trim());
    for (const p of parts) {
      const m = p.match(/^(\d{1,2})[-\s]([A-Za-z]{3,})$/);
      if (!m) continue;
      const dom = Number(m[1]);
      const monthName = m[2].substring(0, 3);
      const monthIdx = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        .findIndex(mn => mn.toLowerCase() === monthName.toLowerCase());
      if (monthIdx === -1) continue;
      if (dayOfMonth_(today) === dom && monthNum_(today) === monthIdx + 1) return true;
    }
    if (parts.length === 1 && /^\d{1,2}$/.test(parts[0])) {
      logWarn_('cadenceMatchesToday_', 'Task ' + t['Task ID'] + ': Yearly cadence has no month ("' + detail +
        '") — add one as "DD-Mon" in Task Master. Currently never fires.');
    }
    return false;
  }

  logWarn_('cadenceMatchesToday_', 'Task ' + t['Task ID'] + ': unrecognised cadence "' + cadence + '" — skipped.');
  return false;
}

function inDateRange_(start, end, today) {
  const s = new Date(start), e = new Date(end);
  const t = new Date(dateOnly_(today));
  return t >= new Date(dateOnly_(s)) && t <= new Date(dateOnly_(e));
}

/** Set of yyyy-MM-dd strings from Holiday Calendar where Applies To = "All" (or blank). */
function getHolidayDatesForDailyCadence_() {
  const sheet = getSheet_(SHEETS.HOLIDAYS);
  const { rows } = readRows_(sheet, HOLIDAYS_HEADER_ROW);
  const set = new Set();
  rows.forEach(r => {
    if (!r['Date']) return;
    const appliesTo = String(r['Applies To [All / Employee Name]'] || 'All').trim();
    if (appliesTo === '' || appliesTo.toLowerCase() === 'all') {
      set.add(dateOnly_(r['Date']));
    }
  });
  return set;
}

// ---- Today's Assignment Queue helpers (fixed layout, see Config.gs) ------
function readQueueRows_(queueSheet) {
  const lastRow = queueSheet.getLastRow();
  if (lastRow < QUEUE_DATA_START_ROW) return [];
  const values = queueSheet.getRange(QUEUE_DATA_START_ROW, 1, lastRow - QUEUE_DATA_START_ROW + 1, 10).getValues();
  return values
    .filter(r => r[QUEUE_COLS.queueId - 1] !== '')
    .map(r => ({
      queueId: r[QUEUE_COLS.queueId - 1],
      employeeName: r[QUEUE_COLS.employeeName - 1],
      taskDescription: r[QUEUE_COLS.taskDescription - 1],
      source: r[QUEUE_COLS.source - 1],
      taskId: r[QUEUE_COLS.taskId - 1],
      includeToday: r[QUEUE_COLS.includeToday - 1],
      supervisorName: r[QUEUE_COLS.supervisorName - 1],
      locked: String(r[QUEUE_COLS.locked - 1]).toUpperCase() === 'Y'
    }));
}

function appendQueueRow_(queueSheet, fields) {
  const nextRow = Math.max(queueSheet.getLastRow() + 1, QUEUE_DATA_START_ROW);
  const queueId = nextSequenceQueue_(queueSheet);
  const rowValues = new Array(8).fill('');
  rowValues[QUEUE_COLS.queueId - 1] = queueId;
  rowValues[QUEUE_COLS.employeeName - 1] = fields.employeeName;
  rowValues[QUEUE_COLS.taskDescription - 1] = fields.taskDescription;
  rowValues[QUEUE_COLS.source - 1] = fields.source;
  rowValues[QUEUE_COLS.taskId - 1] = fields.taskId || '';
  rowValues[QUEUE_COLS.includeToday - 1] = fields.includeToday || 'Y';
  rowValues[QUEUE_COLS.supervisorName - 1] = fields.supervisorName || '';
  rowValues[QUEUE_COLS.locked - 1] = 'N';
  queueSheet.getRange(nextRow, 1, 1, 8).setValues([rowValues]);
  // Priority (col I) auto-VLOOKUP formula, matching the sheet's existing pattern:
  queueSheet.getRange(nextRow, QUEUE_COLS.priority).setFormula(
    '=IFERROR(VLOOKUP(E' + nextRow + ',\'Task Master\'!$A:$O,15,FALSE()),"")'
  );
  return nextRow;
}

function nextSequenceQueue_(queueSheet) {
  const lastRow = queueSheet.getLastRow();
  let max = 0;
  if (lastRow >= QUEUE_DATA_START_ROW) {
    const ids = queueSheet.getRange(QUEUE_DATA_START_ROW, 1, lastRow - QUEUE_DATA_START_ROW + 1, 1).getValues();
    ids.forEach(row => {
      const m = String(row[0]).match(/^Q-(\d+)$/);
      if (m) max = Math.max(max, Number(m[1]));
    });
  }
  return 'Q-' + String(max + 1).padStart(4, '0');
}
