/**
 * File 5 of 8 — QueueLock.gs
 * Runs at ASSIGNMENT_QUEUE_LOCK_TIME_IST (default 08:30). Locks every
 * "Include Today = Y" row in the Queue, copies it into Daily Checklist as
 * the permanent record for the day, rebuilds the Google Form with today's
 * task list, and (at DAILY_FORM_SEND_TIME_IST) WhatsApps the form link to
 * the Senior Authority.
 */

function lockQueueAndPublish() {
  const cfg = CFG();
  const today = new Date();
  const todayStr = todayStr_();
  const queueSheet = getSheet_(SHEETS.QUEUE);
  const dcSheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const { map: dcMap } = readRows_(dcSheet, 1);

  const lastRow = queueSheet.getLastRow();
  if (lastRow < QUEUE_DATA_START_ROW) {
    logWarn_('lockQueueAndPublish', 'Queue is empty — nothing to lock.');
    return { published: 0 };
  }

  const numRows = lastRow - QUEUE_DATA_START_ROW + 1;
  const range = queueSheet.getRange(QUEUE_DATA_START_ROW, 1, numRows, 10);
  const values = range.getValues();
  const published = [];

  for (let i = 0; i < values.length; i++) {
    const row = values[i];
    const queueId = row[QUEUE_COLS.queueId - 1];
    if (!queueId) continue;
    const includeToday = String(row[QUEUE_COLS.includeToday - 1]).toUpperCase();
    const alreadyLocked = String(row[QUEUE_COLS.locked - 1]).toUpperCase() === 'Y';
    if (alreadyLocked) continue;
    if (includeToday !== 'Y') continue;

    const employeeName = row[QUEUE_COLS.employeeName - 1];
    const taskDescription = row[QUEUE_COLS.taskDescription - 1];
    const supervisorName = row[QUEUE_COLS.supervisorName - 1];
    const priority = row[QUEUE_COLS.priority - 1] || 'Medium';
    const taskId = row[QUEUE_COLS.taskId - 1];

    const checklistId = nextChecklistId_(dcSheet, today);
    const dcRow = dcSheet.getLastRow() + 1;
    const rowVals = {};
    rowVals['Checklist ID'] = checklistId;
    rowVals['Date'] = today;
    rowVals['Task ID'] = taskId;
    rowVals['Employee Name'] = employeeName;
    rowVals['Task Description'] = taskDescription;
    rowVals['Status'] = 'Pending';
    rowVals['Reminder Count'] = 0;
    rowVals['Escalated (Y/N)'] = 'N';
    rowVals['Supervisor Name'] = supervisorName;
    rowVals['Color Status'] = 'Yellow';
    rowVals['Priority (auto-VLOOKUP)'] = priority;
    rowVals['Delivery Status (Sent/Delivered/Failed/Pending)'] = 'Pending';
    rowVals['Needs Manual Reconciliation (Y/N)'] = 'N';

    const headerRowArr = new Array(dcSheet.getLastColumn()).fill('');
    Object.keys(dcMap).forEach(h => {
      if (rowVals.hasOwnProperty(h)) headerRowArr[dcMap[h] - 1] = rowVals[h];
    });
    dcSheet.getRange(dcRow, 1, 1, headerRowArr.length).setValues([headerRowArr]);

    // Lock the queue row + stamp Locked At
    queueSheet.getRange(QUEUE_DATA_START_ROW + i, QUEUE_COLS.locked).setValue('Y');
    queueSheet.getRange(QUEUE_DATA_START_ROW + i, QUEUE_COLS.lockedAt).setValue(new Date());

    published.push({ checklistId, employeeName, taskDescription, priority });
  }

  logInfo_('lockQueueAndPublish', 'Published ' + published.length + ' task(s) to Daily Checklist for ' + todayStr + '.');
  applyDailyChecklistColorFormatting_();

  if (published.length > 0) {
    refreshChecklistForm_(todayStr, published);
  } else {
    logWarn_('lockQueueAndPublish', 'No rows had Include Today = Y — form was not rebuilt.');
  }
  return { published: published.length };
}

function nextChecklistId_(dcSheet, today) {
  const dateTag = Utilities.formatDate(today, CFG().timeZone, 'yyyyMMdd');
  const lastRow = dcSheet.getLastRow();
  let max = 0;
  if (lastRow > 1) {
    const ids = dcSheet.getRange(2, 1, lastRow - 1, 1).getValues();
    ids.forEach(r => {
      const m = String(r[0]).match(/^CL-\d{8}-(\d+)$/);
      if (m) max = Math.max(max, Number(m[1]));
    });
  }
  return 'CL-' + dateTag + '-' + String(max + 1).padStart(3, '0');
}

/**
 * Separate step (call from a trigger at DAILY_FORM_SEND_TIME_IST, a few
 * minutes after the lock trigger) so the WhatsApp send always happens after
 * the form is fully rebuilt, even if lockQueueAndPublish runs slowly.
 */
function sendChecklistFormToSeniorAuthority() {
  const cfg = CFG();
  const formId = getProp_('GOOGLE_FORM_ID', '');
  if (!formId) {
    logWarn_('sendChecklistFormToSeniorAuthority', 'No GOOGLE_FORM_ID yet — run "Lock Queue & Send Form" once first.');
    return;
  }
  const form = FormApp.openById(formId);
  const url = form.getPublishedUrl();
  const message = 'Good morning ' + cfg.seniorAuthorityName + ',\n\n' +
    "Today's checklist form is ready (" + todayStr_() + '):\n' + url +
    '\n\nPlease mark completed tasks and add remarks for anything not done.';
  const result = sendWhatsAppText_(cfg.seniorAuthorityPhone, message);
  logInfo_('sendChecklistFormToSeniorAuthority', 'Sent=' + result.ok + ' to ' + cfg.seniorAuthorityPhone);
}

// ---- Conditional-format color status on Daily Checklist -------------------
function applyDailyChecklistColorFormatting_() {
  const sheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const map = headerMap_(sheet, 1);
  const colorCol = map['Color Status'];
  if (!colorCol) return;
  const lastRow = Math.max(sheet.getLastRow(), 2);
  const range = sheet.getRange(2, colorCol, lastRow - 1, 1);

  const rules = sheet.getConditionalFormatRules().filter(r => {
    const ranges = r.getRanges();
    return !ranges.some(rg => rg.getColumn() === colorCol && rg.getSheet().getSheetId() === sheet.getSheetId());
  });
  const colors = { Green: '#B7E1CD', Yellow: '#FFF2CC', Orange: '#FCE5CD', Red: '#F4CCCC', Grey: '#D9D9D9' };
  Object.keys(colors).forEach(text => {
    rules.push(SpreadsheetApp.newConditionalFormatRule()
      .whenTextEqualTo(text)
      .setBackground(colors[text])
      .setRanges([range])
      .build());
  });
  sheet.setConditionalFormatRules(rules);
}
