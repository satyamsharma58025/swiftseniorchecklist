/**
 * File 6 of 8 — FormSync.gs
 * One Google Form is reused every day — its questions are rebuilt each
 * morning to match that day's locked Daily Checklist rows. Responses are
 * NOT linked via Form's native spreadsheet destination (that would create
 * its own mismatched columns); instead an onFormSubmit trigger (installed
 * by Triggers.gs) reads the response directly and writes it into the
 * existing "Form Responses" sheet in our own format.
 */

function createOrGetDailyForm_() {
  let formId = getProp_('GOOGLE_FORM_ID', '');
  if (formId) {
    try {
      return FormApp.openById(formId);
    } catch (e) {
      logWarn_('createOrGetDailyForm_', 'Stored GOOGLE_FORM_ID no longer valid, creating a new form.');
    }
  }
  const form = FormApp.create('Senior Authority Daily Checklist');
  form.setDescription('Mark today\'s tasks Done, and add remarks for anything Not Done.');
  form.setCollectEmail(false);
  getScriptProps_().setProperty('GOOGLE_FORM_ID', form.getId());

  // Install the submit trigger the first time the form is created.
  ScriptApp.newTrigger('onDailyFormSubmit')
    .forForm(form)
    .onFormSubmit()
    .create();

  return form;
}

/**
 * Rebuilds the form's questions for `dateStr`, from `publishedRows`
 * (array of {checklistId, employeeName, taskDescription, priority}).
 */
function refreshChecklistForm_(dateStr, publishedRows) {
  const form = createOrGetDailyForm_();
  form.setTitle('Senior Authority Daily Checklist — ' + dateStr);

  // Clear all existing items before rebuilding.
  form.getItems().forEach(item => form.deleteItem(item));

  const choices = publishedRows.map(r =>
    r.checklistId + ' — ' + r.employeeName + ' — ' + r.taskDescription +
    (r.priority ? ' [' + r.priority + ']' : '')
  );

  const doneItem = form.addCheckboxItem();
  doneItem.setTitle('Checklist IDs completed today (tick everything DONE)')
    .setChoiceValues(choices)
    .setRequired(false);

  const remarksItem = form.addParagraphTextItem();
  remarksItem.setTitle('Remarks for anything NOT done')
    .setHelpText('One line per task, format: ChecklistID: your remark  (e.g. "CL-20260911-003: waiting on HR")')
    .setRequired(false);

  logInfo_('refreshChecklistForm_', 'Form rebuilt with ' + choices.length + ' task(s) for ' + dateStr + '.');
}

/**
 * Installable trigger target — fires the moment the Senior Authority
 * submits the form. Delegates to processFormSubmission_ which does the
 * actual parsing + Daily Checklist updates, shared with the manual
 * "Reprocess Form Responses" menu action (processUnprocessedFormResponses).
 */
function onDailyFormSubmit(e) {
  try {
    const itemResponses = e.response.getItemResponses();
    let doneRaw = '';
    let remarksRaw = '';
    itemResponses.forEach(ir => {
      const title = ir.getItem().getTitle();
      if (title.indexOf('completed today') !== -1) {
        const vals = ir.getResponse(); // array for checkbox items
        doneRaw = Array.isArray(vals) ? vals.join('; ') : String(vals);
      } else if (title.indexOf('NOT done') !== -1) {
        remarksRaw = ir.getResponse();
      }
    });

    const frSheet = getSheet_(SHEETS.FORM_RESPONSES);
    const cfg = CFG();
    const today = todayStr_();
    const { rows: existingToday } = readRows_(frSheet, 1);
    const isCorrection = existingToday.some(r => dateOnly_(r['Date']) === today && String(r['Processed (Y/N)']).toUpperCase() === 'Y');

    frSheet.appendRow([
      e.response.getTimestamp(),
      cfg.seniorAuthorityName,
      new Date(),
      doneRaw,
      remarksRaw,
      'N',
      isCorrection ? 'Y' : 'N'
    ]);

    processUnprocessedFormResponses();
  } catch (err) {
    logError_('onDailyFormSubmit', err);
  }
}
