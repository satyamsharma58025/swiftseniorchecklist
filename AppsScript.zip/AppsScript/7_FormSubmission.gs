/**
 * File 7 of 8 — FormSubmission.gs
 * Turns raw Form Responses rows (Processed = N) into Daily Checklist
 * updates: ticked Checklist IDs -> Status "Done"; IDs mentioned in the
 * remarks paragraph -> Status "Not Done" + that remark. Anything not
 * mentioned either way is left Pending, to be picked up by the reminder
 * sweep. Also callable directly from the menu to reprocess/catch up.
 */

function processUnprocessedFormResponses() {
  const frSheet = getSheet_(SHEETS.FORM_RESPONSES);
  const { map: frMap, rows: frRows } = readRows_(frSheet, 1);
  const dcSheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const { map: dcMap, rows: dcRows } = readRows_(dcSheet, 1);

  let processedCount = 0;

  frRows.forEach(fr => {
    if (String(fr['Processed (Y/N)']).toUpperCase() === 'Y') return;

    const doneIds = extractChecklistIds_(fr['Checklist IDs Marked Done (raw)']);
    const remarksById = parseRemarks_(fr['Remarks for Not Done Tasks (raw)']);

    doneIds.forEach(id => {
      const target = dcRows.find(r => r['Checklist ID'] === id);
      if (!target) {
        logWarn_('processUnprocessedFormResponses', 'Done-marked Checklist ID not found: ' + id);
        return;
      }
      setField_(dcSheet, dcMap, target._row, 'Status', 'Done');
      setField_(dcSheet, dcMap, target._row, 'Color Status', 'Green');
      setField_(dcSheet, dcMap, target._row, 'Delivery Status (Sent/Delivered/Failed/Pending)', 'Delivered');
      setField_(dcSheet, dcMap, target._row, 'Form Submission Timestamp', fr['Timestamp']);
    });

    Object.keys(remarksById).forEach(id => {
      const target = dcRows.find(r => r['Checklist ID'] === id);
      if (!target) {
        logWarn_('processUnprocessedFormResponses', 'Remark given for unknown Checklist ID: ' + id);
        return;
      }
      if (doneIds.indexOf(id) !== -1) return; // Done wins if both were somehow submitted
      setField_(dcSheet, dcMap, target._row, 'Status', 'Not Done');
      setField_(dcSheet, dcMap, target._row, 'Senior Remarks (from Form)', remarksById[id]);
      setField_(dcSheet, dcMap, target._row, 'Color Status', 'Red');
      setField_(dcSheet, dcMap, target._row, 'Delivery Status (Sent/Delivered/Failed/Pending)', 'Delivered');
      setField_(dcSheet, dcMap, target._row, 'Form Submission Timestamp', fr['Timestamp']);
    });

    setField_(frSheet, frMap, fr._row, 'Processed (Y/N)', 'Y');
    processedCount++;
  });

  logInfo_('processUnprocessedFormResponses', 'Processed ' + processedCount + ' form response row(s).');
  return processedCount;
}

/** "CL-20260911-001 — Santosh Guddu — ... [Low]; CL-20260911-002 — ..." -> ["CL-20260911-001","CL-20260911-002"] */
function extractChecklistIds_(raw) {
  if (!raw) return [];
  const text = String(raw);
  const matches = text.match(/CL-\d{8}-\d{3}/g);
  return matches ? Array.from(new Set(matches)) : [];
}

/** "CL-20260911-003: waiting on HR\nCL-20260911-005: material delay" -> {id: remark} */
function parseRemarks_(raw) {
  const result = {};
  if (!raw) return result;
  String(raw).split(/\r?\n/).forEach(line => {
    const m = line.match(/^\s*(CL-\d{8}-\d{3})\s*[:\-]\s*(.+)$/);
    if (m) result[m[1]] = m[2].trim();
  });
  return result;
}
