/**
 * File 8 of 8 — ReminderEscalation.gs
 * Two triggers:
 *   reminderSweep()  — every N hours (Triggers.gs), nudges still-open tasks
 *                       and escalates to the Supervisor once the threshold
 *                       from Task Master is hit.
 *   eodCutoffSweep()  — once daily at EOD_CUTOFF_TIME_IST, anything still
 *                       Pending is marked Not Done / Red.
 */

function reminderSweep() {
  const cfg = CFG();
  const dcSheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const { map: dcMap, rows: dcRows } = readRows_(dcSheet, 1);
  const taskMap = buildTaskLookup_(); // Task ID -> {escalationThreshold, ...}
  const empMap = buildEmployeePhoneLookup_();
  const today = todayStr_();
  const now = new Date();

  let reminded = 0, escalated = 0;

  dcRows.forEach(r => {
    if (dateOnly_(r['Date']) !== today) return;
    if (r['Status'] === 'Done') return;
    if (String(r['Escalated (Y/N)']).toUpperCase() === 'Y') return;

    const priority = String(r['Priority (auto-VLOOKUP)'] || 'Medium');
    const intervalHours = (priority === 'High') ? cfg.reminderIntervalHoursHigh : cfg.reminderIntervalHours;
    const lastReminded = r['Last Reminded'];
    const baseline = lastReminded ? new Date(lastReminded) : new Date(r['Date']);
    const dueForReminder = hoursBetween_(baseline, now) >= intervalHours;
    if (!dueForReminder) return;

    const employeePhone = empMap[r['Employee Name']];
    const reminderCount = Number(r['Reminder Count'] || 0) + 1;

    const msg = 'Reminder: your task "' + r['Task Description'] + '" (' + r['Checklist ID'] +
      ') is still not marked done. Please complete it and reply here with an update.';
    sendWhatsAppText_(employeePhone, msg);

    setField_(dcSheet, dcMap, r._row, 'Reminder Count', reminderCount);
    setField_(dcSheet, dcMap, r._row, 'Last Reminded', now);
    reminded++;

    const task = taskMap[r['Task ID']];
    const threshold = task ? task.escalationThreshold : cfg.escalationThresholdDefault;
    const highCapHit = (priority === 'High' && reminderCount >= cfg.maxRemindersPerDayHigh);

    if (reminderCount >= threshold || highCapHit) {
      escalateTask_(dcSheet, dcMap, r, reminderCount);
      escalated++;
    } else {
      setField_(dcSheet, dcMap, r._row, 'Color Status', 'Orange');
      setField_(dcSheet, dcMap, r._row, 'Status', 'Not Done');
    }
  });

  logInfo_('reminderSweep', reminded + ' reminder(s) sent, ' + escalated + ' escalation(s) raised.');
  return { reminded, escalated };
}

function escalateTask_(dcSheet, dcMap, checklistRow, reminderCount) {
  const cfg = CFG();
  const now = new Date();

  setField_(dcSheet, dcMap, checklistRow._row, 'Escalated (Y/N)', 'Y');
  setField_(dcSheet, dcMap, checklistRow._row, 'Escalated At', now);
  setField_(dcSheet, dcMap, checklistRow._row, 'Color Status', 'Grey');
  setField_(dcSheet, dcMap, checklistRow._row, 'Escalation Tier (1/2)', 1);

  const empMap = buildEmployeeRowLookup_();
  const emp = empMap[checklistRow['Employee Name']];
  const supervisorPhone = emp ? emp['Supervisor Phone'] : '';
  const supervisorName = checklistRow['Supervisor Name'] || (emp ? emp['Supervisor Name'] : '');

  const msg = 'Escalation: ' + checklistRow['Employee Name'] + ' has not completed "' +
    checklistRow['Task Description'] + '" (' + checklistRow['Checklist ID'] + ') after ' +
    reminderCount + ' reminder(s). Please follow up.';
  sendWhatsAppText_(supervisorPhone, msg);

  const escSheet = getSheet_(SHEETS.ESCALATION_LOG);
  const escId = nextSequence_(escSheet, 1, 'Escalation ID', 'ESC-', 4);
  escSheet.appendRow([
    escId,
    checklistRow['Checklist ID'],
    checklistRow['Date'],
    checklistRow['Employee Name'],
    checklistRow['Task Description'],
    supervisorName,
    reminderCount,
    now,
    'N',
    '',
    1
  ]);

  // Tier-2 (Plant Head) escalation, only if enabled in README settings.
  if (cfg.tier2Enabled && emp && emp['Plant Head Phone'] && String(emp['Plant Head Phone']).indexOf('TBD') === -1) {
    sendWhatsAppText_(emp['Plant Head Phone'],
      'Tier-2 escalation: ' + checklistRow['Employee Name'] + ' — "' + checklistRow['Task Description'] +
      '" (' + checklistRow['Checklist ID'] + ') is still unresolved after Supervisor notification.');
    setField_(dcSheet, dcMap, checklistRow._row, 'Escalation Tier (1/2)', 2);
  }
}

function eodCutoffSweep() {
  const dcSheet = getSheet_(SHEETS.DAILY_CHECKLIST);
  const { map: dcMap, rows: dcRows } = readRows_(dcSheet, 1);
  const today = todayStr_();
  let marked = 0;

  dcRows.forEach(r => {
    if (dateOnly_(r['Date']) !== today) return;
    if (r['Status'] === 'Done') return;
    setField_(dcSheet, dcMap, r._row, 'Status', 'Not Done');
    setField_(dcSheet, dcMap, r._row, 'Color Status', 'Red');
    if (!r['Senior Remarks (from Form)']) {
      setField_(dcSheet, dcMap, r._row, 'Senior Remarks (from Form)', 'Missed - no remarks yet');
    }
    marked++;
  });

  logInfo_('eodCutoffSweep', marked + ' task(s) marked Not Done at EOD cutoff.');
  return marked;
}

// ---- Lookup builders --------------------------------------------------
function buildTaskLookup_() {
  const sheet = getSheet_(SHEETS.TASK_MASTER);
  const { rows } = readRows_(sheet, 1);
  const map = {};
  rows.forEach(r => {
    map[r['Task ID']] = { escalationThreshold: Number(r['Escalation Threshold']) || 2 };
  });
  return map;
}
function buildEmployeePhoneLookup_() {
  const sheet = getSheet_(SHEETS.EMPLOYEES);
  const { rows } = readRows_(sheet, 1);
  const map = {};
  rows.forEach(r => { map[r['Employee Name']] = r['Phone']; });
  return map;
}
function buildEmployeeRowLookup_() {
  const sheet = getSheet_(SHEETS.EMPLOYEES);
  const { rows } = readRows_(sheet, 1);
  const map = {};
  rows.forEach(r => { map[r['Employee Name']] = r; });
  return map;
}
