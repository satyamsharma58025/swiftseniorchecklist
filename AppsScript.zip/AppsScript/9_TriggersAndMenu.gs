/**
 * File 9 of 9 — TriggersAndMenu.gs
 * Custom menu (manual controls) + installUnifiedTriggers() which sets up
 * every time-driven trigger this system needs. Run installUnifiedTriggers
 * once from the menu after setup; it's safe to run again later (it removes
 * old ones first, so it never double-installs).
 */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('📋 Checklist Admin')
    .addItem('1. Generate Today\'s Queue (draft)', 'menuGenerateQueue_')
    .addItem('2. Lock Queue && Send Form Now', 'menuLockAndSend_')
    .addSeparator()
    .addItem('Reprocess Form Responses', 'menuReprocessForm_')
    .addItem('Run Reminder Sweep Now', 'menuReminderSweep_')
    .addItem('Run End-of-Day Cutoff Now', 'menuEodSweep_')
    .addSeparator()
    .addItem('Install Automatic Triggers', 'installUnifiedTriggers')
    .addItem('Remove All Automatic Triggers', 'removeUnifiedTriggers')
    .addItem('View Script Log', 'menuOpenLog_')
    .addToUi();
}

function menuGenerateQueue_() {
  runSafely_('generateTodaysQueue', () => {
    const n = generateTodaysQueue();
    SpreadsheetApp.getUi().alert('Drafted ' + n + " task instance(s) into Today's Assignment Queue.\n" +
      'Review it, untick anything to skip, then run step 2.');
  }, true);
}
function menuLockAndSend_() {
  runSafely_('lockQueueAndPublish', () => {
    const res = lockQueueAndPublish();
    if (res.published > 0) sendChecklistFormToSeniorAuthority();
    SpreadsheetApp.getUi().alert('Locked and published ' + res.published + ' task(s). Form link sent (if WhatsApp is configured).');
  }, true);
}
function menuReprocessForm_() {
  runSafely_('processUnprocessedFormResponses', () => {
    const n = processUnprocessedFormResponses();
    SpreadsheetApp.getUi().alert('Processed ' + n + ' form response row(s).');
  }, true);
}
function menuReminderSweep_() {
  runSafely_('reminderSweep', () => {
    const res = reminderSweep();
    SpreadsheetApp.getUi().alert('Reminders sent: ' + res.reminded + '. Escalations raised: ' + res.escalated + '.');
  }, true);
}
function menuEodSweep_() {
  runSafely_('eodCutoffSweep', () => {
    const n = eodCutoffSweep();
    SpreadsheetApp.getUi().alert(n + ' still-open task(s) marked Not Done.');
  }, true);
}
function menuOpenLog_() {
  const sh = SpreadsheetApp.getActive().getSheetByName(SHEETS.SCRIPT_LOG);
  if (sh) SpreadsheetApp.setActiveSheet(sh);
  else SpreadsheetApp.getUi().alert('No log entries yet.');
}

/**
 * Installs every time-driven trigger this system needs, at the times
 * configured in the README & Settings sheet. Removes any triggers this
 * script previously created first, so re-running is always safe.
 */
function installUnifiedTriggers() {
  removeUnifiedTriggers();
  const cfg = CFG();

  ScriptApp.newTrigger('generateTodaysQueue')
    .timeBased().atHour(6).nearMinute(0).everyDays(1).inTimezone(cfg.timeZone).create();

  const lockHour = Number(cfg.queueLockTime.split(':')[0]);
  ScriptApp.newTrigger('lockQueueAndPublish')
    .timeBased().atHour(lockHour).nearMinute(30).everyDays(1).inTimezone(cfg.timeZone).create();

  const sendHour = Number(cfg.formSendTime.split(':')[0]);
  ScriptApp.newTrigger('sendChecklistFormToSeniorAuthority')
    .timeBased().atHour(sendHour).nearMinute(0).everyDays(1).inTimezone(cfg.timeZone).create();

  ScriptApp.newTrigger('reminderSweep')
    .timeBased().everyHours(2).create(); // fires every 2h; each row's own High/Standard interval governs whether it actually reminds

  const eodHour = Number(cfg.eodCutoffTime.split(':')[0]);
  ScriptApp.newTrigger('eodCutoffSweep')
    .timeBased().atHour(eodHour).nearMinute(0).everyDays(1).inTimezone(cfg.timeZone).create();

  // Form-submit trigger is created once, inside createOrGetDailyForm_(),
  // the first time the form itself is created — not duplicated here.

  logInfo_('installUnifiedTriggers', 'Installed 5 time-driven triggers.');
  SpreadsheetApp.getUi().alert('Automatic triggers installed:\n' +
    '• 06:00 — generate draft queue\n' +
    '• ' + cfg.queueLockTime + ' — lock queue & publish\n' +
    '• ' + cfg.formSendTime + ' — WhatsApp form link to Senior Authority\n' +
    '• every 2h — reminder/escalation sweep\n' +
    '• ' + cfg.eodCutoffTime + ' — end-of-day cutoff');
}

function removeUnifiedTriggers() {
  const managed = new Set([
    'generateTodaysQueue', 'lockQueueAndPublish', 'sendChecklistFormToSeniorAuthority',
    'reminderSweep', 'eodCutoffSweep'
  ]);
  ScriptApp.getProjectTriggers().forEach(t => {
    if (managed.has(t.getHandlerFunction()) && t.getEventType() === ScriptApp.EventType.CLOCK) {
      ScriptApp.deleteTrigger(t);
    }
  });
}
