# Senior Checklist System — Apps Script Setup

This replaces the Apps Script project you lost. It runs entirely inside the
Google Sheet (no n8n needed) and reproduces + extends everything the old
workflow did: daily task generation, the review queue, the Google Form,
WhatsApp reminders and escalation, and the audit log.

## 1. Import the updated workbook

1. Open Google Sheets → **File → Import → Upload** → choose
   `Senior_Checklist_System_v7.xlsx` → **Import location: Create new
   spreadsheet** (don't merge into the old file — start clean so the new
   Employees/Task Master rows and the Checklist Templates tab come in
   correctly).
2. Fill in every `TBD - add phone number` cell in the **Employees** tab —
   the automation silently skips WhatsApp sends for anyone whose phone is
   still TBD (it logs a warning in Script Log instead of failing loudly).
3. Review the new **Checklist Templates** tab. For each row you want live,
   copy it into **Task Master** with a real Task ID, Cadence and Schedule
   Detail — the template tab is a picklist, not itself read by the script.

## 2. Add the script

1. In the new spreadsheet: **Extensions → Apps Script**.
2. Delete the default empty `Code.gs`.
3. For each file in this folder (`1_Config.gs` through `9_TriggersAndMenu.gs`),
   click **+ → Script** in the Apps Script editor, name it exactly the same
   (without the leading number if you prefer — order doesn't matter to
   Apps Script, the numbers are just so you read them in order), and paste
   the contents in.
4. Also open **Project Settings** (gear icon) → paste `appsscript.json`'s
   content into the manifest if the editor shows one (or just set the time
   zone to `Asia/Kolkata` there and skip the manifest — the webapp block
   only matters once you deploy in step 4 below).
5. Save. Reload the spreadsheet — you should see a new **📋 Checklist
   Admin** menu appear after a few seconds.

## 3. WhatsApp — Meta Cloud API credentials

You need a Meta WhatsApp Business Cloud API app (the same WABA number
referenced in the sheet's `WHATSAPP_PHONE_NUMBER_ID` setting already
implies you were using this API before).

1. In the Apps Script editor: **Project Settings → Script Properties → Add
   script property**:
   - `WHATSAPP_TOKEN` = your permanent access token (never put this in the
     spreadsheet itself — Script Properties is the private place for it)
   - `WHATSAPP_WEBHOOK_VERIFY_TOKEN` = any string you make up, e.g.
     `senior-checklist-verify-2026`
2. Double-check `WHATSAPP_PHONE_NUMBER_ID` in the **README & Settings**
   sheet matches your WABA's phone number ID (it already does — copied
   from your v6 workbook).

## 4. Deploy the webhook (to receive employee WhatsApp replies)

Only needed if you want employees' WhatsApp replies auto-recorded in Daily
Checklist's "Employee Response" column. Skip this section if that's not
needed yet — everything else works without it.

1. **Deploy → New deployment → type: Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
2. Copy the resulting `/exec` URL.
3. In Meta's WhatsApp Business Platform (developers.facebook.com) → your
   app → WhatsApp → Configuration → Webhook: paste the URL, and for
   "Verify token" use the same string you set as
   `WHATSAPP_WEBHOOK_VERIFY_TOKEN` above. Click Verify and Save.
4. Subscribe to the `messages` field.

## 5. Install the automatic schedule

Open the sheet → **📋 Checklist Admin → Install Automatic Triggers**.
This installs (all in Asia/Kolkata time, read live from README & Settings):

| Time | Function | What it does |
|---|---|---|
| 06:00 | `generateTodaysQueue` | Expands Task Master into today's draft rows in the Queue |
| 08:30 (`ASSIGNMENT_QUEUE_LOCK_TIME_IST`) | `lockQueueAndPublish` | Locks the Queue, writes Daily Checklist rows, rebuilds the Google Form |
| 09:00 (`DAILY_FORM_SEND_TIME_IST`) | `sendChecklistFormToSeniorAuthority` | WhatsApps the form link to the Senior Authority |
| every 2h | `reminderSweep` | Nudges open tasks (each task's own High/Standard interval from README decides if it actually sends) and escalates to the Supervisor once the threshold is hit |
| 19:00 (`EOD_CUTOFF_TIME_IST`) | `eodCutoffSweep` | Anything still Pending is marked Not Done / Red |

The Google Form's own submit trigger is installed automatically the first
time the form is created — you don't need to add it separately.

**Between 06:00 and 08:30 is your review window** — open Today's
Assignment Queue, untick "Include Today" on anything you want to skip, or
add an ad-hoc manual row, before the 08:30 lock runs.

## 6. Test it manually first

Before trusting the schedule, run each step once from the menu in order:
**Generate Today's Queue → Lock Queue & Send Form Now → Run Reminder Sweep
Now**. Check Script Log (bottom of the menu) after each step — every
warning and error is written there with a timestamp, so nothing fails
silently.

## Notes / known limitations

- **Yearly tasks with no month** (flagged in the README — e.g. a task
  whose Schedule Detail is just `20`, with no month) will never fire.
  Fix by changing Schedule Detail to `DD-Mon` format (e.g. `20-Mar`).
- **Quarterly cadence** assumes Indian-FY quarter-end months (Mar/Jun/Sep/Dec).
  Edit the `qMonths` array in `4_ChecklistGeneration.gs` if your quarters
  differ.
- If two tasks are open for the same employee at once, an inbound WhatsApp
  reply is recorded against the older one and the row is flagged **Needs
  Manual Reconciliation = Y** rather than guessed at.
- Tier-2 (Plant Head) escalation only fires if `ESCALATION_TIER_2_ENABLED`
  is `Y` in README & Settings **and** that employee's Plant Head Phone is
  filled in (currently TBD for everyone).
