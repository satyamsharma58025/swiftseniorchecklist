```
ROLE
You are a senior full-stack engineer working inside my existing repo "swiftseniorchecklist" (Next.js 16 App Router, React 19, Prisma 5 + PostgreSQL, NextAuth v4 credentials/JWT, zod 4, luxon, vitest, deployed on Render). It is an internal ops tool for Swift Strips India: a Senior Authority ticks a daily checklist, employees get WhatsApp reminders, missed tasks escalate to supervisors. Make surgical diffs. Do not refactor unrelated code, rename things, or change the Prisma schema (none of the tasks below need it).

CURRENT STATE OF THE REPO (already on main, do not redo)
- The Google Form + WhatsApp + n8n integration v1 is merged: /api/integrations/form/today and /submit, src/lib/form-submission.ts, src/lib/integration-auth.ts, the checklist page "Senior form" card + AutoRefresh, integrations/ folder (README, FormBridge.gs, n8n workflow).
- Auth default-deny is merged: src/proxy.ts (Next 16 replacement for middleware.ts) + src/lib/route-access.ts (classifyRoute / requireRole) + tests. It deliberately exempts /login, /api/auth/*, /_next, /api/cron/*, /api/integrations/*, /api/webhooks/whatsapp, because those are protected in-handler by a shared secret (x-cron-secret == CRON_SECRET, constant-time, fail-closed) or by Meta's HMAC.
- A stray file swift-form-whatsapp-n8n.patch sits in the repo root. Delete it.

STEP 0 - APPLY MY PATCH
I have "swift-integration-v2.patch" (ONE commit, made on top of current main). Run: git apply --check swift-integration-v2.patch, then git am it. It adds:
  - POST /api/integrations/whatsapp/inbound (secret-protected) and src/lib/whatsapp-inbound.ts (processInboundWhatsAppPayload), which /api/webhooks/whatsapp now also uses. It fixes a crash where normalizePhone() threw on foreign/short sender numbers (a 500 makes Meta retry forever), and uses the IST business date.
  - integrations/n8n/Production_Patch_Forward_Replies_To_App.json, an updated Swift_Senior_Checklist_Form_WhatsApp.workflow.json, updated integrations/README.md, and 7 new tests.
Do NOT rewrite these files. Review them against this prompt, fix real defects only. If the patch fails to apply, stop and tell me why instead of improvising.
Then run npm install, npx prisma generate, npx tsc --noEmit, npm run lint, npx vitest run, npm run build. Report baseline vs after. Pre-existing failures are listed separately, not silently fixed.

PRODUCTION CONTEXT YOU MUST RESPECT
- One WhatsApp Business number (phoneNumberId 1158085794064004) serves several systems. Meta's webhook for it points at MY PRODUCTION n8n (path "whatsapp-incoming"), which runs the boss voice-note task flow and the "menu/report" flow. Meta allows ONE callback URL per app. NEVER change code, docs or config so that Meta is expected to call this app's /api/webhooks/whatsapp. n8n forwards employee TEXT replies to POST /api/integrations/whatsapp/inbound instead. The /api/webhooks/whatsapp route stays as-is for direct use and tests.
- Only plain text that is not the keyword "menu" or "report" is forwarded, so messages from bosses must never be recorded as employee replies. The app ignores senders who are not active employees.
- The production n8n instance is UTC-based. The new workflow sets its own timezone (Asia/Kolkata). Never write cron expressions for it assuming the instance default.
- WhatsApp templates in production use different language codes (en, en_US, en_IN). A mismatch fails with Meta error 132001. The three templates this app relies on are senior_daily_checklist|en, not_done_reminder|en, escalation_alert|en. They do NOT appear in the production workflow, so their existence must be verified, not assumed.
- Recipient phone format for WhatsApp: country code + number, digits only (919876543210). Use toWhatsAppNumber() from src/lib/business-logic.ts (returns null instead of throwing).
- The production Google Sheet of employees (Employees tab: name, phone, active) is probably cleaner than the app's Employee table.

FACTS YOU MUST NOT GET WRONG
- Checklist codes look like CL-YYYYMMDD-<up to 8 alphanumerics>, e.g. CL-20260920-YT001 (NOT the old CL-YYYYMMDD-### sheet format). Regex: CL-\d{8}-[A-Za-z0-9]+, case-insensitive, matched against known codes with a boundary check (AB1 must not match AB12).
- Business timezone is Asia/Kolkata. Dates are stored as @db.Date at UTC midnight of the IST date. Use getBusinessToday(), never the server's local date.
- runCronJob() allows one successful run per (jobName, runDate). Do not build anything that needs repeated runs of one cron job per day.
- render.yaml runs lock-queue at 08:30 IST ("0 3 * * *"). It creates the day's DailyChecklistItem rows and must run before the 09:00 IST form send.
- Enums: ChecklistStatus PENDING|DONE|NOT_DONE; NotificationStatus QUEUED|SENT|FAILED|SKIPPED_NO_PHONE|SKIPPED_OUTSIDE_WINDOW; Role MANAGER|SENIOR|EMPLOYEE.
- Response shapes of /api/integrations/form/today, /form/submit, /whatsapp/inbound and /api/cron/reminder-sweep/ack are contracts with the n8n workflow. Keep them stable.

TASKS (in this order; one commit each; stop and report if any acceptance check fails)

TASK 1 - Verify and harden auth (proxy already exists)
a) Confirm Next 16 actually runs src/proxy.ts (read the Next docs in node_modules or the upgrade guide). Confirm src/middleware.ts is gone. Show how you verified.
b) Defence in depth: the proxy is a single point of failure. Add a small helper requireSessionRole(roles) using getServerSession(authOptions) and call it inside the mutating handlers: PATCH /api/checklist/item/[id], POST /api/admin/tasks, POST /api/queue/[date]. Reuse requireRole from route-access.ts. Reads of checklist/dashboard need any signed-in user.
c) Extend route-access tests: /api/integrations/whatsapp/inbound and /api/integrations/form/* are exempt; PATCH /api/checklist/item/x needs MANAGER or SENIOR; /api/admin/tasks needs MANAGER or SENIOR; an unknown /api/foo requires auth.
d) Do not touch the secret-protected routes' auth logic.

TASK 2 - Remove default credentials
Search the repo for hard-coded admin emails/passwords (for example admin@swift.local / Admin@12345), seed scripts and README text. Seeding must read ADMIN_EMAIL and ADMIN_PASSWORD from env, refuse passwords shorter than 12 characters, and never print passwords. Note in integrations/README.md that the production admin password must be rotated. I will do the rotation myself in the database/Render, so do not attempt it.

TASK 3 - Readiness script (read-only)
Add scripts/check-integration-readiness.ts (tsx) and npm script "check:integration". It prints: active employees with no valid WhatsApp number (toWhatsAppNumber === null); employees with no supervisor; supervisors with no valid phone; whether Settings.seniorAuthorityPhone or env SENIOR_AUTHORITY_PHONE is set; whether GOOGLE_FORM_URL and CRON_SECRET are set; today's DailyChecklistItem count; and how many checklist rows for today still have supervisorName equal to their own employeeName (rows created before the supervisor fix). Exit non-zero on blockers (no senior phone, no form URL, no CRON_SECRET).
Optional flag --check-templates: if WHATSAPP_ACCESS_TOKEN and WHATSAPP_BUSINESS_ACCOUNT_ID are set, call the Graph API GET /{waba-id}/message_templates?fields=name,language,status and verify senior_daily_checklist (en), not_done_reminder (en), escalation_alert (en) exist with status APPROVED. Report missing ones and any that exist under a different language code. Never print the token. If the env vars are absent, skip with a clear message.

TASK 4 - Employee phone import from my production sheet
Inspect scripts/import-employees.ts first. Extend it minimally so it can read a CSV export of the production Employees tab (columns "Employee Name" or "Name", "Phone" or "Phone Number", "Active"). Default to DRY RUN: print, per employee, name match (exact, then case-insensitive), current phone, proposed phone (via toWhatsAppNumber), and what would change. Only write with an explicit --apply flag. Never create employees in this task, only update phones of existing ones; list unmatched names. Add tests for the CSV parsing and matching functions (pure functions, no DB).

TASK 5 - Admin Settings screen
There is no UI for Settings.seniorAuthorityName / seniorAuthorityPhone. Add /admin/settings (MANAGER or SENIOR only; server component + server action or API route with zod validation and toWhatsAppNumber validation) plus a link in AppNav's admin menu. Match the existing neo-brutalist classes (neo-border, neo-shadow-sm, sticker, brand-display). Only those two fields.

TASK 6 - Route tests with mocked Prisma
vitest tests mocking @/lib/prisma (see src/lib/whatsapp-inbound.test.ts for the pattern) for /api/integrations/form/submit (401 without secret; 400 bad body; duplicate responseId is a no-op; 404 no rows; status transitions; escalation resolved on DONE; newlyNotDone only contains rows that changed to NOT_DONE) and /api/integrations/form/today (401; formLinkSentToday true/false; choices start with the code). Also /api/integrations/whatsapp/inbound (401; forwards to the processor). No real database.

RULES
- No new dependencies unless unavoidable; say why if you add one.
- Never log or commit secrets. Secrets come only from env.
- Fail closed: an unset CRON_SECRET must reject everyone.
- Do not edit anything under integrations/n8n/ or integrations/google-form/ unless you find a concrete bug; explain it if you do.
- Do NOT fix these; list them under "Observations" instead: withCronLock being a no-op; /api/cron/reminder-sweep returning items with reminderCount > 0 as "due"; the once-per-day CronRunLog making repeated reminder sweeps impossible; the queue POST route auth semantics beyond Task 1.

ACCEPTANCE CRITERIA
1. tsc, lint, vitest and next build pass, or pre-existing failures are unchanged and listed.
2. Unauthenticated: /dashboard -> 307 to /login; /api/dashboard/summary -> 401; PATCH /api/checklist/item/x -> 401; POST /api/admin/tasks -> 401; /api/integrations/form/today -> 401; same URL with the right x-cron-secret -> 200. An EMPLOYEE session PATCHing a checklist item -> 403.
3. Submitting the same Google Form responseId twice changes data once.
4. POST /api/integrations/whatsapp/inbound: 401 without the secret; with the secret, a text from an active employee's number stores employeeResponse on their single open task; from any other number it changes nothing and returns matched:false.
5. npm run check:integration exits non-zero when GOOGLE_FORM_URL is unset.

DELIVERABLE FORMAT
Small commits. At the end reply with: (1) checklist of what was done per task, (2) exact env vars I must set on Render (GOOGLE_FORM_URL, SENIOR_AUTHORITY_PHONE, SENIOR_AUTHORITY_NAME, ADMIN_EMAIL/ADMIN_PASSWORD if seeding, and optionally WHATSAPP_ACCESS_TOKEN + WHATSAPP_BUSINESS_ACCOUNT_ID for the template check), (3) manual steps still mine: create the Google Form, deploy the Apps Script, import the n8n workflow and create its two Header Auth credentials, paste the production patch into the existing n8n workflow and wire ONE connection, verify the three WhatsApp templates, rotate the admin password, (4) assumptions, (5) "Observations" list.
```
